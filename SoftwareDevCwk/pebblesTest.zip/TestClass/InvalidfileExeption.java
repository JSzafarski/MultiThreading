public class InvalidfileExeption extends Exception {

    public InvalidfileExeption(String errormsg) {
        super(errormsg);
        //gets a string with the error passed to it.
    }

}
