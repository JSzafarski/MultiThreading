1)To run the tests on the class methods go to CMD. 
2)Using "CD" xommand locate the file where the test class exists once it has been unzipped.
3)compile Junit  using thsi syntax : javac -cp <-- Path to JUnit Jar -->;. FileName.java
4)then run JUnit using this syntax(will depend where it resides in your pc) :java -cp <-- Path to JUnit Jar -->;<-- Path to Hamcrest-core Jar -->;. org.junit.runner.JUnitCore FileName


